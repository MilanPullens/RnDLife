#!/usr/bin/env python
# coding: utf-8

# In[14]:


import pandas
pandas.options.mode.chained_assignment = None # None|'warn'|'raise'

demData = pandas.read_csv("data/RnD/demographic.csv")
dietData = pandas.read_csv("data/RnD/diet.csv")
exmData = pandas.read_csv("data/RnD/examination.csv")
labData = pandas.read_csv("data/RnD/labs.csv")
medData = pandas.read_csv("data/RnD/medications.csv",usecols=[0,12])
quesData = pandas.read_csv("data/RnD/questionnaire.csv")
newData = pandas.read_sas("data/RnD/DEMO_I.xpt", format='xport')
deathData = pandas.read_csv('data/RnD/Deaths.txt', sep='\t')

filteredDemData = demData[['SEQN','RIAGENDR','RIDAGEYR','INDFMPIR']]
filteredDietData = dietData[['SEQN','DR1TALCO','DR1TCAFF','DR1TKCAL']]
filteredExmData = exmData[['SEQN','BPXPLS','BMXWT','BMXHT','BMXBMI']]
filteredLabData = labData[['SEQN','LBXHGB','LBXWBCSI','LBXRBCSI']]
filteredMedData = medData[['SEQN','RXDCOUNT']]
filteredQuesData = quesData[['SEQN','MCQ220','PAD680']]
filteredNewData = newData[['SEQN','RIAGENDR','RIDAGEYR','INDFMPIR']]
filteredDeathData = deathData[['Gender Code','Single-Year Ages Code','Crude Rate']]

filteredDemData.dropna(inplace = True)
filteredDietData.dropna(inplace = True)
filteredExmData.dropna(inplace = True)
filteredLabData.dropna(inplace = True)
filteredMedData.dropna(inplace = True)
filteredNewData.dropna(inplace = True)


filteredQuesData['ACTLIG'] = quesData['PAD645'].fillna(0)
filteredQuesData['ACTMOD'] = quesData['PAD630'].fillna(0) + quesData['PAD675'].fillna(0)
filteredQuesData['ACTVIG'] = quesData['PAD615'].fillna(0) + quesData['PAD660'].fillna(0)
filteredQuesData['ACTTOT'] = filteredQuesData['ACTLIG'] + filteredQuesData['ACTMOD'] + filteredQuesData['ACTVIG']
filteredQuesData['SCRTOT'] = quesData['PAQ710'].fillna(0) + quesData['PAQ715'].fillna(0)
filteredQuesData['100CIG'] = quesData['SMQ020']
filteredQuesData['CIGDAY'] = quesData['SMD650'].fillna(0)

filteredQuesData.dropna(inplace = True)

filteredData1 = pandas.merge(filteredDemData, filteredDietData, on="SEQN")
filteredData2 = pandas.merge(filteredData1, filteredExmData, on="SEQN")
filteredData3 = pandas.merge(filteredData2, filteredLabData, on="SEQN")
filteredData4 = pandas.merge(filteredData3, filteredMedData, on="SEQN")
filteredData5 = pandas.merge(filteredData4, filteredQuesData, on="SEQN")

filteredFinalData = filteredData5.drop_duplicates(subset=['SEQN'])

filteredDeathData.drop(filteredDeathData.index[1])

#filteredFinalData.size/24
#filteredFinalData.head(100)
#filteredNewData.round(3)
filteredDeathData.head
#filteredNewData.head(100)


# In[ ]:




